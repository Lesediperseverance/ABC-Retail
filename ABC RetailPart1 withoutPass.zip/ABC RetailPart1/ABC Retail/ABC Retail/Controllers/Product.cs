﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using ABC_Retail.Models;
using ABC_Retail.Services;

namespace ABC_Retail.Controllers
{
    public class ProductController : Controller
    {
        private readonly TableServices _tableServices;
        private readonly AzureBlobServices _blobService;

        public ProductController(TableServices tableServices, AzureBlobServices blobService)
        {
            _tableServices = tableServices;
            _blobService = blobService;
        }


        // GET: Product
        public async Task<IActionResult> Index()
        {
            var products = await _tableServices.GetProductsAsync();
            return View(products);
        }

        // GET: Product/Details/{id}
        public async Task<IActionResult> Details(string id)
        {
            if (string.IsNullOrWhiteSpace(id)) return NotFound();

            var product = await _tableServices.GetProductAsync(id);
            if (product == null) return NotFound();

            return View(product);
        }

        // GET: Product/Create
        public IActionResult Create() => View(new Product());

        // POST: Product/Create
        [HttpPost]
        public async Task<IActionResult> Create(Product product, IFormFile image)
        {
            if (!ModelState.IsValid) return View(product);

            if (image != null)
            {
                var blobUrl = await _blobService.UploadFileAsync(image);
                product.ImageBlobName = blobUrl ?? "";
            }

            await _tableServices.AddProductAsync(product);
            return RedirectToAction(nameof(Index));
        }

        // GET: Product/Edit/{id}
        public async Task<IActionResult> Edit(string id)
        {
            if (string.IsNullOrWhiteSpace(id)) return NotFound();

            var product = await _tableServices.GetProductAsync(id);
            if (product == null) return NotFound();

            return View(product);
        }

        // POST: Product/Edit/{id}
        [HttpPost]
        public async Task<IActionResult> Edit(Product updatedProduct, IFormFile? newImage)
        {
            if (!ModelState.IsValid) return View(updatedProduct);

            if (newImage != null)
            {
                var blobUrl = await _blobService.UploadFileAsync(newImage);
                updatedProduct.ImageBlobName = blobUrl ?? updatedProduct.ImageBlobName;
            }

            await _tableServices.UpdateProductAsync(updatedProduct);
            return RedirectToAction(nameof(Index));
        }

        // GET: Product/Delete/{id}
        public async Task<IActionResult> Delete(string id)
        {
            if (string.IsNullOrWhiteSpace(id)) return NotFound();

            var product = await _tableServices.GetProductAsync(id);
            if (product == null) return NotFound();

            return View(product);
        }

        // POST: Product/Delete/{id}
        [HttpPost, ActionName("Delete")]
        public async Task<IActionResult> DeleteConfirmed(string id)
        {
            await _tableServices.DeleteProductAsync(id);
            return RedirectToAction(nameof(Index));
        }
    }
}