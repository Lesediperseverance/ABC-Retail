﻿using Azure.Storage.Queues;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;
using ABC_Retail.Models;

namespace ABC_Retail.Services
{
    public class QueueServices
    {
        private readonly QueueClient _queueClient;

        public QueueServices(IConfiguration configuration)
        {
            var queueName = configuration["AzureStorage:QueueName"];
            var connectionString = configuration["AzureStorage:ConnectionString"];
            _queueClient = new QueueClient(connectionString, queueName);
            _queueClient.CreateIfNotExists();
        }

        public async Task SendAsync(string message)
        {
            if (!_queueClient.Exists()) return;

            // Optional: Encode message to avoid issues with special characters
            var encodedMessage = Convert.ToBase64String(Encoding.UTF8.GetBytes(message));
            await _queueClient.SendMessageAsync(encodedMessage);
        }
    }
}