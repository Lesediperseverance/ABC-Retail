﻿using Azure;
using Azure.Storage.Files.Shares;
using Azure.Storage.Files.Shares.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.Extensions.Options;
using System.Text;
using ABC_Retail.Models;

namespace ABC_Retail.Services
{
    public class FileSharesServices : IAzureFileShareService
    {
        private readonly ShareClient _shareClient;
        private readonly string? _rootDirectory;

        public FileSharesServices(IOptions<AzureFilesOptions> options)
        {
            var o = options?.Value ?? throw new ArgumentNullException(nameof(options));

            if (string.IsNullOrWhiteSpace(o.ShareName))
                throw new ArgumentException("ShareName cannot be null or whitespace.", nameof(o.ShareName));

            if (string.IsNullOrWhiteSpace(o.ConnectionString))
                throw new ArgumentException("ConnectionString cannot be null or whitespace.", nameof(o.ConnectionString));

            _shareClient = new ShareClient(o.ConnectionString, o.ShareName);
            _rootDirectory = o.RootDirectory;

            _shareClient.CreateIfNotExists();

            if (!string.IsNullOrWhiteSpace(_rootDirectory))
            {
                _shareClient.GetRootDirectoryClient()
                            .GetSubdirectoryClient(_rootDirectory)
                            .CreateIfNotExists();
            }
        }

        private ShareDirectoryClient GetDirectory(string? directory)
        {
            var dir = _shareClient.GetRootDirectoryClient();
            string path = CombineAzurePath(_rootDirectory, directory);

            if (!string.IsNullOrWhiteSpace(path))
            {
                foreach (var segment in path.Split('/', StringSplitOptions.RemoveEmptyEntries))
                {
                    dir = dir.GetSubdirectoryClient(segment);
                    dir.CreateIfNotExists();
                }
            }

            return dir;
        }

        private static string CombineAzurePath(params string?[] parts)
            => string.Join('/', parts.Where(p => !string.IsNullOrWhiteSpace(p)));

        public async Task<IReadOnlyList<FileItem>> ListAsync(string? directory = null)
        {
            var dir = GetDirectory(directory);
            var items = new List<FileItem>();

            var opts = new ShareDirectoryGetFilesAndDirectoriesOptions
            {
                IncludeExtendedInfo = true
            };

            await foreach (ShareFileItem item in dir.GetFilesAndDirectoriesAsync(opts))
            {
                items.Add(new FileItem
                {
                    Name = item.Name,
                    IsDirectory = item.IsDirectory,
                    Size = item.IsDirectory ? null : item.FileSize,
                    LastModified = item.Properties?.LastModified
                });
            }

            return items
                .OrderByDescending(i => i.IsDirectory)
                .ThenBy(i => i.Name, StringComparer.OrdinalIgnoreCase)
                .ToList();
        }
        public async Task UploadAsync(string fileName, Stream fileStream)
        {
            var directoryClient = _shareClient.GetRootDirectoryClient();
            var fileClient = directoryClient.GetFileClient(fileName);

            await fileClient.CreateAsync(fileStream.Length);
            await fileClient.UploadAsync(fileStream);
        }

        public async Task<Stream> DownloadAsync(string fileName)
        {
            var directoryClient = _shareClient.GetRootDirectoryClient();
            var fileClient = directoryClient.GetFileClient(fileName);

            var download = await fileClient.DownloadAsync();
            return download.Value.Content;
        }

        public async Task<List<string>> ListFilesAsync(string customerId)
        {
            var directoryClient = _shareClient.GetRootDirectoryClient();
            var files = new List<string>();

            await foreach (var item in directoryClient.GetFilesAndDirectoriesAsync())
            {
                if (item.IsDirectory) continue;
                if (item.Name.StartsWith(customerId + "_"))
                {
                    files.Add(item.Name);
                }
            }

            return files;
        }

        public async Task UploadAsync(IFormFile file, string? directory = null, CancellationToken ct = default)
        {
            if (file == null || file.Length == 0) throw new InvalidOperationException("Empty file.");

            var dir = GetDirectory(directory);
            var fileClient = dir.GetFileClient(file.FileName);

            await fileClient.CreateAsync(file.Length, cancellationToken: ct);

            using var stream = file.OpenReadStream();
            const int chunk = 4 * 1024 * 1024;
            long offset = 0;
            byte[] buffer = new byte[chunk];

            while (true)
            {
                int read = await stream.ReadAsync(buffer.AsMemory(0, buffer.Length), ct);
                if (read <= 0) break;

                using var chunkStream = new MemoryStream(buffer, 0, read, writable: false);
                await fileClient.UploadRangeAsync(
                    range: new HttpRange(offset, read),
                    content: chunkStream,
                    cancellationToken: ct
                );
                offset += read;
            }
        }

        public async Task<Stream> DownloadAsync(string name, string? directory = null)
        {
            var dir = GetDirectory(directory);
            var fileClient = dir.GetFileClient(name);
            var download = await fileClient.DownloadAsync();
            return download.Value.Content;
        }

        public Task DeleteAsync(string name, string? directory = null)
        {
            var dir = GetDirectory(directory);
            var fileClient = dir.GetFileClient(name);
            return fileClient.DeleteIfExistsAsync();
        }

        public async Task CreateDirectoryAsync(string name, string? parentDirectory = null)
        {
            if (string.IsNullOrWhiteSpace(name)) return;
            var dir = GetDirectory(parentDirectory).GetSubdirectoryClient(name);
            await dir.CreateIfNotExistsAsync();
        }

        public async Task<bool> ExistsAsync(string name, string? directory = null)
        {
            var dir = GetDirectory(directory);
            var fileClient = dir.GetFileClient(name);
            var exists = await fileClient.ExistsAsync();
            return exists.Value;
        }
    }
}