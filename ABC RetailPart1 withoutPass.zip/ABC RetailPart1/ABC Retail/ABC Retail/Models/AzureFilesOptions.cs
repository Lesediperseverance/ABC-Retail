﻿namespace ABC_Retail.Models
{
    public class AzureFilesOptions
    {
        public string ConnectionString { get; set; } = "";
        public string ShareName { get; set; } = "";
        public string? RootDirectory { get; set; }
    }
}
