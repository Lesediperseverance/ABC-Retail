using ABC_Retail.Models;
using ABC_Retail.Services;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container
builder.Services.AddControllersWithViews();

// Register custom services
builder.Services.AddSingleton<AzureBlobServices>();
builder.Services.AddSingleton<FileSharesServices>();
builder.Services.AddSingleton<QueueServices>();
builder.Services.AddSingleton<TableServices>();

// Optional: Validate connection string early (for debugging)
var connectionString = builder.Configuration["AzureStorage:ConnectionString"];
Console.WriteLine($"Azure Storage Connection: {connectionString}");

// Bind AzureStorage section to AzureFilesOptions
builder.Services.Configure<AzureFilesOptions>(
    builder.Configuration.GetSection("AzureStorage")
);

//  Debug print to confirm ShareName is loaded
var azureFilesOptions = builder.Configuration.GetSection("AzureStorage").Get<AzureFilesOptions>();
Console.WriteLine($"File Share Name: {azureFilesOptions?.ShareName}");

// Build the app
var app = builder.Build();

// Configure the HTTP request pipeline
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
}

app.UseStaticFiles();
app.UseRouting();
app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.Run();