﻿using Azure;
using Azure.Data.Tables;

namespace ABC_Retail.Models
{
    public class Product : ITableEntity
    {
        public string PartitionKey { get; set; } = "PRODUCT";
        public string RowKey { get; set; } = Guid.NewGuid().ToString(); // Unique ID
        public string Name { get; set; }
        public string Sku { get; set; }
        public double Price { get; set; }
        public string ImageBlobName { get; set; } = "";

        // Required by ITableEntity
        public DateTimeOffset? Timestamp { get; set; }
        public ETag ETag { get; set; }
    }
}