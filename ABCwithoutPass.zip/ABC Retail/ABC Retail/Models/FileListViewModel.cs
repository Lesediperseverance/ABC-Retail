﻿namespace ABC_Retail.Models
{
    public class FileListViewModel
    {
        public string CurrentDirectory { get; set; } = "";
        public IReadOnlyList<FileItem> Items { get; set; } = new List<FileItem>();
    }
}
